public class Motos extends Veiculo{
    private int cilindrada;

    public Motos(String marca, String modelo, int ano, double preco, int cilindrada) {
        super(marca, modelo, ano, preco);
        this.cilindrada = cilindrada;
    }

    public int getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(int cilindrada) {
        this.cilindrada = cilindrada;
    }

    public void ImprimirInformacoesMoto(){
        ImprimirInformacoes();
        System.out.println("=|Cilindradas: " + cilindrada + " cc|=");
    }
}
