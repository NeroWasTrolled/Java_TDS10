public class Carros extends Veiculo{
    private int qtdPortas;

    public Carros(String marca, String modelo, int ano, double preco, int qtdPortas) {
        super(marca, modelo, ano, preco);
        this.qtdPortas = qtdPortas;
    }

    public int getQtdPortas() {
        return qtdPortas;
    }

    public void setQtdPortas(int qtdPortas) {
        this.qtdPortas = qtdPortas;
    }

    public void ImprimirInformacoesCarro(){
        ImprimirInformacoes();
        System.out.println("=|Quantidade de portas: " + qtdPortas + "|=");
    }
}
