public class caminhao extends Veiculo{
    private double cargaMaxima;

    public caminhao(String marca, String modelo, int ano, double preco, double cargaMaxima) {
        super(marca, modelo, ano, preco);
        this.cargaMaxima = cargaMaxima;
    }

    public double getCargaMaxima() {
        return cargaMaxima;
    }

    public void setCargaMaxima(double cargaMaxima) {
        this.cargaMaxima = cargaMaxima;
    }

    public void ImprimirInformacoesCaminhao(){
        ImprimirInformacoes();
        System.out.println("=|Carga Máxima: " + cargaMaxima + " toneladas|=");
    }
}
