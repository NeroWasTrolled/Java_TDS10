public class Principal {
    public static void main(String[] args) {
        Carros carro = new Carros("Honda", "Civic", 2020, 109.800, 4);
        Motos moto = new Motos("Honda", "NC 750X", 2018, 55.700, 745);
        caminhao caminho = new caminhao("Volkswagen", "Delivery Express", 2022, 254.899, 1.335);

        System.out.println("=|-----------------|Carro|-----------------|=");
        carro.ImprimirInformacoesCarro();
        System.out.println();
        System.out.println("=|-----------------------------------------|=");
        System.out.println();
        System.out.println("=|-----------------|Moto|-----------------|=");
        moto.ImprimirInformacoesMoto();
        System.out.println();
        System.out.println("=|----------------------------------------|=");
        System.out.println();
        System.out.println("=|-----------------|Caminhão|-----------------|=");
        caminho.ImprimirInformacoesCaminhao();
        System.out.println();
        System.out.println("=|--------------------------------------------|=");
    }
}
