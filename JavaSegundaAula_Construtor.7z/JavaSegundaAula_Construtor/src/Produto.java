public class Produto {
    //Meus Atributos
    private String nome;
    private double preco;

    //meu construtor
    public Produto(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    public boolean ehCaro(){
        return (preco < 100);
    }
}
