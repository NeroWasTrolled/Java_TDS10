public class Casa {
    String nome;
    String cor;
    int numero;

    public Casa(String nome, String cor, int numero) {
        this.nome = nome;
        this.cor = cor;
        this.numero = numero;
    }

    public void abrirPorta(){
        System.out.println("Porta Aberta");
    }

    public void fecharPorta(){
        System.out.println("Porta Fechada");
    }

}
