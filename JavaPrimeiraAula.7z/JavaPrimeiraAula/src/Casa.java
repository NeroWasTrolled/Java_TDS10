public class Casa {
    String nome;
    String cor;
    int numero;
    int tamanho;

    public Casa(String nome, String cor, int numero, int tamanho) {
        this.nome = nome;
        this.cor = cor;
        this.numero = numero;
        this.tamanho = tamanho;
    }

    public void abrirPorta(){
        System.out.println("Porta Aberta");
    }

    public void fecharPorta(){
        System.out.println("Porta Fechada");
    }

    public void demolirCasa(){
        int tamanho = 100;
        while (tamanho > 0){
            System.out.println("Derrubei mais uma parede!!!!");
            tamanho-=1;
        }
        System.out.println("Casa Destruida!");
    }

    public void reconstruirCasa(){
        for(int i=0; i == 100; i = i + 1){
            tamanho +=1;
            System.out.print(tamanho);
        }
        System.out.print("casa reconstruida, agora tem tamanho:" + tamanho);
    }

}
