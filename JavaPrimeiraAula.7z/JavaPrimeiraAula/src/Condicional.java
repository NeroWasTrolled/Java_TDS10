public class Condicional {
    int idade = 28;

    public void comparar(){
        if (idade < 18){
            System.out.println("Não pode entrar");
        }else{
            System.out.println("Pode entrar");
        }
    }
}
