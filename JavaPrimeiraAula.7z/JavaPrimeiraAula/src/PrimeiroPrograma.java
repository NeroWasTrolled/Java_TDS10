import java.util.Scanner;

public class PrimeiroPrograma {
    public static void main(String[] args){

        Condicional c1 = new Condicional();

        c1.comparar();

        Casa casaPong = new Casa("Pong", "rosa", 10);
        Casa casaPietro = new Casa("casa branca", "branca", 140);

        System.out.println(casaPong.cor);
        System.out.println(casaPietro.cor);

        //int idade = 30;
        //boolean menor = idade < 18;
        //System.out.println(menor);
        //float num1;
        //num1 = 1.2F;
        //System.out.println(num1);

        //- / / - / / - / / - / / - / /

        //int valor1 = 10;
        //int valor2 = 20;
        //int soma;
        //soma = valor1 + valor2;
        //System.out.println(soma);
    }



}

