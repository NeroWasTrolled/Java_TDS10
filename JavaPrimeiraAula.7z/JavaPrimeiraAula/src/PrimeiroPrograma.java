import java.util.Scanner;

public class PrimeiroPrograma {

    public static void main(String[] args){

        Scanner scan = new Scanner(System.in);

        Livros livroAlice = new Livros("Alice no pais das maravilhas", "Lewis Carroll", "França Corporation", 1865);
        Livros livroZaras = new Livros("Zaratustra", "Friedrich Nietzsche", "França Corporation", 1883);

        livroAlice.abrirLivro();
        System.out.println("==================================");
        System.out.println();
        System.out.println(livroAlice.nome);
        System.out.println(livroAlice.autor);
        System.out.println(livroAlice.editora);
        System.out.println(livroAlice.ano);
        System.out.println();
        System.out.println("==================================");
        livroAlice.fecharLivro();

        System.out.println("__________________________________");
        System.out.println();
        System.out.println("__________________________________");

        livroZaras.abrirLivro();
        System.out.println("==================================");
        System.out.println();
        System.out.println(livroZaras.nome);
        System.out.println(livroZaras.autor);
        System.out.println(livroZaras.editora);
        System.out.println(livroZaras.ano);
        System.out.println();
        System.out.println("==================================");
        livroZaras.fecharLivro();

        //- / / - / / - / / - / / - / /

        //Condicional c1 = new Condicional();
        //c1.comparar();
        //Casa casaPong = new Casa("Pong", "rosa", 24, 100 );
        //Casa casaPietro = new Casa("casa branca", "branca", 140, 99);
        //System.out.println(casaPong.cor);
        //System.out.println(casaPietro.cor);
        //casaPong.abrirPorta();
        //casaPong.demolirCasa();
        //casaPietro.demolirCasa();
        //System.out.print(casaPietro.tamanho);
        //casaPietro.reconstruirCasa();
        //- / / - / / - / / - / / - / /

        //int idade = 30;
        //boolean menor = idade < 18;
        //System.out.println(menor);
        //float num1;
        //num1 = 1.2F;
        //System.out.println(num1);

        //- / / - / / - / / - / / - / /

        //int valor1 = 10;
        //int valor2 = 20;
        //int soma;
        //soma = valor1 + valor2;
        //System.out.println(soma);
    }



}

