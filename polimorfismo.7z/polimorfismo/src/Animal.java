public abstract class Animal {
    protected String nome;
    protected int numeroPatas;

    public abstract void som();
}
