public class TesteAula03 {
    public static void main (String[] args){
        Pessoa pessoa1 = new Pessoa("Caio", 123456);
        Aluno aluno1 = new Aluno("pong", 1234, 5);
        Funcionario func1 = new Funcionario("Carlos", 56677, "TI");


        aluno1.quemSouEu();

        //func1.falarNome();

    }
}
